const express = require('express');
const path = require('path');
const UserManager = require('../classes/UserManager');

const router = express.Router();
const userManager = new UserManager();

router.post('/register', (req, res) => {
  const { username, password } = req.body;
  try {
    userManager.createUser(username, password);
    res.redirect('/dashboard');
  } catch (error) {
    res.status(400).send(error.message);
  }
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  try {
    const user = userManager.loginUser(username, password);
    res.redirect('/dashboard');
  } catch (error) {
    res.status(400).send(error.message);
  }
});

router.get('/change-password', (req, res) => {
  const currentUser = userManager.getCurrentUser();
    if (!currentUser) {
      return res.status(401).send('Unauthorized');
    }
    res.sendFile(path.join(__dirname, '../views/changePassword.html'));
});

router.post('/change-password', (req, res) => {
  const { password } = req.body; 
  try {
    const currentUser = userManager.getCurrentUser();
    if (!currentUser) {
      return res.status(401).send('Unauthorized');
    }
    const user = userManager.changePassword(currentUser.username, password);
    res.status(200).send('Password changed successfully');
  } catch (error) {
    res.status(400).send(error.message);
  }
});

router.get('/logout', (req, res) => {
  userManager.logout();
  res.redirect('/');
});

router.get('/dashboard', (req, res) => {
  if (!userManager.currentUser) {
    return res.status(401).send('Unauthorized');
  }
  res.sendFile(path.join(__dirname, '../views/dashboard.html'));
});

module.exports = router;
