const User = require('./User');

class UserManager {
  constructor() {
    this.currentUser = null;
    this.users = []; // Mocked user storage
  }

  getCurrentUser() {
    return this.currentUser;
  }

  createUser(username, password) {
    const existingUser = this.users.find(user => user.username === username);
    if (existingUser) {
      throw new Error('User already exists');
    }
    const newUser = new User(username, password);
    this.users.push(newUser);
    this.currentUser = newUser;
    return newUser;
  }

  loginUser(username, password) {
    const user = this.users.find(user => user.username === username && user.password === password);
    if (user) {
      this.currentUser = user;
      return user;
    }
    throw new Error('Invalid credentials');
  }

  changePassword(username, newPassword) {
    const user = this.users.find(user => user.username === username);
    if (user) {
      user.password = newPassword;
      return user;
    }
    throw new Error('User not found');
  }

  logout() {
    this.currentUser = null;
  }
}

module.exports = UserManager;
