// Mocking DB functions, actual implementation will be done using Jest and Mockito
class UserDatabase {
    saveUser(user) {
      // This function will be mocked during testing
      throw new Error('Function not implemented');
    }
  
    getUser(username) {
      // This function will be mocked during testing
      throw new Error('Function not implemented');
    }
  }
  
  module.exports = UserDatabase;
  