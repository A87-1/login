# Social Media Login

## Overview
A simple social media login and registration system built with Node.js and Express.js, with Cypress for end-to-end testing and Jest for unit testing.

## Features
- User Registration
- User Login
- Password Change (VG functionality)
- Logout
- Cypress e2e tests
- Jest unit tests with mock database using Mockito
- GitHub Actions for CI/CD

## Installation
1. Clone the repository
2. Run `npm install` to install dependencies
3. Start the server with `npm start` and to stop CTRL + C

## Running Tests
- Run Jest unit tests: `npm run test`
- For Cypress please run `npm start` in separate cmd or console then run bellow commands
- Opens Cypress UI `npm run cypress:open`
- Runs Cypress e2e tests headlessly `npm run cypress:run`

## GitHub Actions
Automated CI tests will run on every push to the `main` branch.


