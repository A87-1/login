module.exports = {
    testPathIgnorePatterns: [
      '/node_modules/',     // Ignore node_modules
      '/cypress/'           // Ignore Cypress tests
    ],
  };
  