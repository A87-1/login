describe('Change Password', () => {
  before(() => {
    // Register and log in a user before changing password
    cy.request('POST', '/register', {
      username: 'testChangePassword',
      password: 'testChangePassword'
    });
  });

  it('should allow logged-in user to change password', () => {
    cy.visit('/dashboard');

    // Navigate to change password page
    cy.get('a[href="/change-password"]').click();

    // Change password
    cy.get('#password').type('testChangePasswordNew');
    cy.get('form[action="/change-password"]').submit();

    // Check for success message
    cy.contains('Password changed successfully');
  });
});
