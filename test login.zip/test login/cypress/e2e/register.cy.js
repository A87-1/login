describe('User Registration', () => {
  it('should register a new user and redirect to the dashboard', () => {
    cy.visit('/');

    // Register a new user
    cy.get('#register-username').type('testregister');
    cy.get('#register-password').type('testregister');
    cy.get('form[action="/register"]').submit();

    // Check if redirected to dashboard
    cy.url().should('include', '/dashboard');
    cy.contains('Welcome to your dashboard');
  });
});
