
  describe('User Login', () => {
    before(() => {
      // Register a user before logging in
      cy.request('POST', '/register', {
        username: 'testlogin',
        password: 'testlogin'
      });
    });
  
    it('should log in with valid credentials and redirect to the dashboard', () => {
      cy.visit('/');
  
      // Login with registered user
      cy.get('#login-username').type('testlogin');
      cy.get('#login-password').type('testlogin');
      cy.get('form[action="/login"]').submit();
  
      // Check if redirected to dashboard
      cy.url().should('include', '/dashboard');
      cy.contains('Welcome to your dashboard');
    });
  });
  