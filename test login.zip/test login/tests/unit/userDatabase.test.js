const UserDatabase = require('../../src/classes/UserDatabase');

describe('UserDatabase Tests', () => {
  let userDatabaseMock;

  beforeEach(() => {
    userDatabaseMock = new UserDatabase();
  });

  test('should save user to database', () => {
    // Mocking the saveUser method
    const saveUserMock = jest.spyOn(userDatabaseMock, 'saveUser').mockImplementation(() => 'User saved');

    const user = { username: 'testuser', password: 'testpassword' };
    expect(userDatabaseMock.saveUser(user)).toBe('User saved');
    expect(saveUserMock).toHaveBeenCalledWith(user);

    // Restore the original implementation
    saveUserMock.mockRestore();
  });

  test('should get user from database', () => {
    // Mocking the getUser method
    const getUserMock = jest.spyOn(userDatabaseMock, 'getUser').mockImplementation(() => ({
      username: 'testuser',
      password: 'testpassword',
    }));

    const username = 'testuser';
    const user = userDatabaseMock.getUser(username);
    expect(user.username).toBe('testuser');
    expect(user.password).toBe('testpassword');
    expect(getUserMock).toHaveBeenCalledWith(username);

    // Restore the original implementation
    getUserMock.mockRestore();
  });
});
