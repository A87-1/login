const UserManager = require('../../src/classes/UserManager');
const User = require('../../src/classes/User');

describe('UserManager', () => {
  let userManager;

  beforeEach(() => {
    userManager = new UserManager();
  });

  test('should create a new user', () => {
    const user = userManager.createUser('testuser', 'testpass');
    expect(user).toBeInstanceOf(User);
    expect(user.username).toBe('testuser');
    expect(user.password).toBe('testpass');
    expect(userManager.getCurrentUser()).toBe(user);
  });

  test('should not allow duplicate usernames', () => {
    userManager.createUser('testuser', 'testpass');
    expect(() => userManager.createUser('testuser', 'newpass')).toThrow('User already exists');
  });

  test('should login user with correct credentials', () => {
    userManager.createUser('testuser', 'testpass');
    const user = userManager.loginUser('testuser', 'testpass');
    expect(user.username).toBe('testuser');
    expect(userManager.getCurrentUser()).toBe(user);
  });

  test('should not login user with incorrect credentials', () => {
    userManager.createUser('testuser', 'testpass');
    expect(() => userManager.loginUser('testuser', 'wrongpass')).toThrow('Invalid credentials');
  });

  test('should change password successfully', () => {
    userManager.createUser('testuser', 'testpass');
    userManager.changePassword('testuser', 'newpass');
    const user = userManager.loginUser('testuser', 'newpass');
    expect(user.password).toBe('newpass');
  });

  test('should not change password for non-existent user', () => {
    expect(() => userManager.changePassword('nonexistent', 'newpass')).toThrow('User not found');
  });

  test('should handle logout correctly', () => {
    userManager.createUser('testuser', 'testpass');
    userManager.logout();
    expect(userManager.getCurrentUser()).toBeNull();
  });
});
